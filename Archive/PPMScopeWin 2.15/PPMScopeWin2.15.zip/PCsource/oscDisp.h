/* ==============================================================================
 * Author:  Jonathan Weaver, jonw0224@aim.com
 * E-mail Contact: jonw0224@aim.com
 * Description:  Header file for oscilloscope graphs.
 * Version: 2.14
 * Date: 3/17/2011
 * Filename:  oscDisp.c, oscDisp.h
 *
 * Versions History:  
 *      2.01 - 9/20/2006 - Created file
 *      2.14 - 1/31/2011 - Modifications for colors.
 *		2.14 - 3/17/2011 - Added channel weight support
 *
 * Copyright (C) 2006 - 2011 Jonathan Weaver
 * 
 * This file is part of PPMScope.
 * 
 * PPMScope is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 * 
 * ============================================================================== 
 */
 
#define DIVISIONSX 10
#define DIVISIONSY 8
#define SPECTDIVY   5
#define SPECTPHDIVY 4

#define MODE_STOP 1
#define MODE_RUN 2
#define MODE_HOLD 4
#define MODE_XY 8
#define MODE_FREQMAGLOG 16
#define MODE_CHAENABLED 32
#define MODE_CHBENABLED 64

#define RECONST_TRIANGLE 0
#define RECONST_SINC 1
#define RECONST_SQUARE 2
#define RECONST_POINT 3

#define SCOPE_SCREEN 0
#define SCOPE_FREQMAG 1
#define SCOPE_FREQPHASE 2

#define CM_SETSCREENTYPE    9001
#define CM_GETSCREENTYPE    9002

#define GETCOLORBG          1
#define GETCOLORGR          2
#define GETCOLORCHA         3
#define GETCOLORCHB         4
#define GETCOLORCUR1        5
#define GETCOLORCUR2        6
#define GETCOLORTRIG        7

#define CHANNELA            0
#define CHANNELB            1
#define WEIGHTA             1
#define WEIGHTB             1

BOOL CALLBACK oscDispProc (HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam);

/* Returns an oscilloscope display color
 * whichColor: 1 = Background Color, 2 = Grid Color, 3 = Channel A Color, 4 = Channel B Color, 5 = Cursor 1 Color, 6 = Cursor 2 Color, 7 = Trigger Color
 * return: the color as an int, or -1 if whichColor is invalid */
int oscGetColor(int whichColor);

/* Sets the oscilloscope display colors
 * scrbgcolor: Screen Background Color
 * scrfgcolor: Grid Color
 * channelAColor: Channel A Color
 * channelBColor: Channel B Color
 * cur1color: Cursor 1 color
 * cur2color: Cursor 2 color
 * triggerColor: Trigger icon color
 * returns: 1*/
int oscSetColors(int scrbgcolor, int scrfgcolor, int channelAColor, int channelBColor, int cur1color, int cur2color, int triggerColor);

/* Gets the display configuration
 * windowMode:  three character array representing the window modes
 *     (SCOPE_SCREEN, SCOPE_FREQMAG, SCOPE_FREQPHASE)
 * returns: 1 */
int oscDispGetConfig(char windowMode[]);

/* Sets the display configuration
 * windowMode:  three character array representing the window modes
 *     (SCOPE_SCREEN, SCOPE_FREQMAG, SCOPE_FREQPHASE)
 * returns: 1 */
int oscDispSetConfig(char windowMode[]);

/* Clears and redraws all the scope windows 
 * returns: 0 */
int refreshScopeWindows();

/* Sets the channel to enabled or disabled 
 * ch: 0 is channel A, 1 is channel B
 * en: 1 is enabled, 0 is disabled
 * returns: 0 */
int setChannelEnabled(int ch, int en);

/* Gets the enabled status of the channel 
 * ch: 0 is channel A, 1 is channel B
 * returns: 1 is enabled, 0 is disabled */
int getChannelEnabled(int ch);

/* Returns the time per division */
double getTimePerDivision();

/* Gets the weight for drawing the channels
 * channel: 0 for channel A and 1 for channel B
 * returns: weight in pixels */
int getPenWeight(int channel);

/* Sets the weight for drawing the channels
 * channel: 0 for channel A and 1 for channel B
 * w: weight to use in pixels
 * returns: 0  */
int setPenWeight(int channel, int w);

