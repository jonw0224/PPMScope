/* ==============================================================================
 * Author:  Jonathan Weaver, jonw0224@aim.com
 * E-mail Contact: jonw0224@aim.com
 * Description:  Side panel window.
 * Version: 2.01
 * Date: 8/17/2006
 * Filename:  panel.c, panel.h
 *
 * Versions History:  
 *      2.01 - 8/17/2006 - created files
 *
 * Copyright (C) 2006 Jonathan Weaver
 * 
 * This file is part of PPMScope.
 * 
 * PPMScope is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 * 
 * ============================================================================== 
 */

#define WM_REFRESHPANEL   9001

//Panel Buttons
#define CM_VOLT_PER_DIV_CHA_F       9261
#define CM_VOLT_PER_DIV_CHA_C       9262
#define CM_VOLT_OFFSET_CHA          9263
#define CM_VOLT_PER_DIV_CHB_F       9264
#define CM_VOLT_PER_DIV_CHB_C       9265
#define CM_VOLT_OFFSET_CHB          9266
#define CM_TRIGGER_DELAY            9267

#define DLG_UNUSED                  0
#define ED_TIME_PER_DIV             9201

#define CM_TIME_PER_DIV_F          9202
#define CM_TIME_PER_DIV_C          9203

#define ED_SAMPLE_RATE              9206
#define ST_TIME                     9207

#define CM_CHA_COLOR                9208
#define CM_CHA_ENABLED              9209
#define CB_CHA_SOURCE               9210
#define ED_VOLT_PER_DIV_CHA         9211
#define CM_VOLT_PER_DIV_CHA_FINC    9212
#define CM_VOLT_PER_DIV_CHA_CINC    9213
#define CM_VOLT_PER_DIV_CHA_FDEC    9214
#define CM_VOLT_PER_DIV_CHA_CDEC    9215
#define ED_VOLT_OFFSET_CHA          9216
#define CM_VOLT_OFFSET_CHA_INC      9217
#define CM_VOLT_OFFSET_CHA_DEC      9218
#define ST_CHA                      9219

#define CM_CHB_COLOR                9220
#define CM_CHB_ENABLED              9221
#define CB_CHB_SOURCE               9222
#define ED_VOLT_PER_DIV_CHB         9223
#define CM_VOLT_PER_DIV_CHB_FINC    9224
#define CM_VOLT_PER_DIV_CHB_CINC    9225
#define CM_VOLT_PER_DIV_CHB_FDEC    9226
#define CM_VOLT_PER_DIV_CHB_CDEC    9227
#define ED_VOLT_OFFSET_CHB          9228
#define CM_VOLT_OFFSET_CHB_INC      9229
#define CM_VOLT_OFFSET_CHB_DEC      9230
#define ST_CHB                      9231

#define CB_TRIGGER_MODE             9232
#define ED_TRIGGER_DELAY            9233
#define CM_TRIGGER_DELAY_INC        9234
#define CM_TRIGGER_DELAY_DEC        9235
    
#define ST_T_CUR1                   9236
#define ST_P_CUR1                   9237
#define ST_CHA_CUR1                 9238
#define ST_CHB_CUR1                 9239
#define ST_T_CUR2                   9240
#define ST_P_CUR2                   9241
#define ST_CHA_CUR2                 9242
#define ST_CHB_CUR2                 9243
#define ST_T_DELTA                  9244
#define ST_P_DELTA                  9245
#define ST_CHA_DELTA                9246
#define ST_CHB_DELTA                9247
#define ST_TRIG                     9248
#define ST_LABA                     9249
#define ST_LABB                     9250
#define ST_LABC                     9251
#define ST_LABD                     9252

#define MATH_F1                     9253
#define ED_MATH_F1                  9254
#define MATH_F2                     9255
#define ED_MATH_F2                  9256
#define MATH_F3                     9257
#define ED_MATH_F3                  9258
#define MATH_F4                     9259
#define ED_MATH_F4                  9260

/* Panel combo box choices */
#define CB_CHOICE1                  2600
#define CB_CHOICE2                  2601
#define CB_CHOICE3                  2602
#define CB_CHOICE4                  2603
#define CB_CHOICE5                  2604
#define CB_CHOICE6                  2605
#define CB_CHOICE7                  2606
#define CB_CHOICE8                  2607
#define CB_CHOICE9                  2608
#define CB_CHOICE10                 2609
#define CB_CHOICE11                 2610
#define CB_CHOICE12                 2611
#define CB_CHOICE13                 2612

/* Measure combo box choices */
#define MEASURE_CHOICE0             2619
#define MEASURE_CHOICE1             2620
#define MEASURE_CHOICE2             2621
#define MEASURE_CHOICE3             2622
#define MEASURE_CHOICE4             2623
#define MEASURE_CHOICE5             2624
#define MEASURE_CHOICE6             2625
#define MEASURE_CHOICE7             2626
#define MEASURE_CHOICE8             2627
#define MEASURE_CHOICE9             2628
#define MEASURE_CHOICE10            2629
#define MEASURE_CHOICE11            2630
#define MEASURE_CHOICE12            2631
#define MEASURE_CHOICE13            2632
#define MEASURE_CHOICE14            2633
#define MEASURE_CHOICE15            2634
#define MEASURE_CHOICE16            2635
#define MEASURE_CHOICE17            2636
#define MEASURE_CHOICE18            2637
#define MEASURE_CHOICE19            2638
#define MEASURE_CHOICE20            2639
#define MEASURE_CHOICE21            2640
#define MEASURE_CHOICE22            2641
#define MEASURE_CHOICE23            2642
#define MEASURE_CHOICE24            2643
#define MEASURE_CHOICE25            2644
#define MEASURE_CHOICE26            2645
#define MEASURE_CHOICE27            2646
#define MEASURE_CHOICE28            2647
#define MEASURE_CHOICE29            2648
#define MEASURE_CHOICE30            2649
#define MEASURE_CHOICE31            2650
#define MEASURE_CHOICE32            2651
#define MEASURE_CHOICE33            2652
#define MEASURE_CHOICE34            2653
#define MEASURE_CHOICE35            2654
#define MEASURE_CHOICE36            2655
#define MEASURE_CHOICE37            2656
#define MEASURE_CHOICE38            2657
#define MEASURE_CHOICE39            2658
#define MEASURE_CHOICE40            2659
#define MEASURE_CHOICE41            2660
#define MEASURE_CHOICE42            2661
#define MEASURE_CHOICE43            2662
#define MEASURE_CHOICE44            2663
#define MEASURE_CHOICE45            2664
#define MEASURE_CHOICE46            2665
#define MEASURE_CHOICE47            2666
#define MEASURE_CHOICE48            2667

/* Width of the control panel on the screen */
#define PANELWIDTH      310

/* Measurements */
char measureFunct[4];

/* constants for channel makeup */
#define CH1ONLY          0
#define CH2ONLY          1
#define NEGCH1ONLY       2
#define NEGCH2ONLY       3
#define CH1PLUSCH2       4
#define NEGCH1PLUSCH2    5
#define CH1LESSCH2       6
#define CH2LESSCH1       7
#define CH1TIMESCH2      8
#define NEGCH1TIMESCH2   9

/* constants for measurement function */
#define SRMSACA               1
#define SRMSACB               2
#define SAVGA                 3
#define SAVGB                 4
#define SDCYCA                5
#define SDCYCB                6
#define SFALLTA               7
#define SFALLTB               8
#define SFREQA                9
#define SFREQB                10
#define SMAGNA                11
#define SMAGNB                12
#define SMAXA                 13
#define SMAXB                 14
#define SMINA                 15
#define SMINB                 16
#define SNDCYCA               17
#define SNDCYCB               18
#define SNPULSEWA             19
#define SNPULSEWB             20
#define SPERIODA              21
#define SPERIODB              22
#define SPERAVGA              23
#define SPERAVGB              24
#define SPERRMSA              25
#define SPERRMSB              26
#define SPERRMSACA            27
#define SPERRMSACB            28
#define SPHASEA               29
#define SPHASEB               30
#define SPTPA                 31
#define SPTPB                 32
#define SPULSEWA              33
#define SPULSEWB              34
#define SRISETA               35
#define SRISETB               36
#define SRMSA                 37
#define SRMSB                 38
#define SSNRA                 39
#define SSNRB                 40
#define STHDA                 41
#define STHDB                 42
#define STHDNA                43
#define STHDNB                44
#define STMAXA                45
#define STMAXB                46
#define STMINA                47
#define STMINB                48
    
/* Statistics on sampling */
typedef struct tagMEASURESTAT {
	double average;
	double q;
	double stddev;
	double max;
	double min;
	double last;
    int NumSamples;
  } MEASURESTAT;

MEASURESTAT mStat[4];

/* Declare Panel procedure */
BOOL CALLBACK PanelProc (HWND hPnl, UINT message, WPARAM wParam, LPARAM lParam);

/* Public procedures */

/* Set the trigger positive */
int setTriggerPos();

/* Set the trigger negative */
int setTriggerNeg();

/* Set the trigger off */
int setTriggerOff();

/* Display the cursor information */
int setCursorInfo(int windowType, double xval[], double cha[], double chb[]);

/* Update the Triggerlevel readout */
int updateTriggerLevel();

/* Updates the channel readouts */
int updateChannelMsg(int j);

/* Updates measurements on the panel */
int doMeasurements();
