/* ==============================================================================
 * Author:  Jonathan Weaver, jonw0224@netscape.net
 * E-mail Contact: jonw0224@aim.com
 * Description:  Oscilloscope display drawing
 * Version: 2.02
 * Date: 3/14/2011
 * Filename:  oscDisp.c, oscDisp.h
 *
 * Versions History:  
 *      2.01 - 9/20/2006 - Created file
 *      2.02 - 3/14/2011 - Added channel weight support
 *
 * Copyright (C) 2011 Jonathan Weaver
 * 
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU General Public License as published by the Free Software
 * Foundation; either version 2 of the License, or (at your option) any later
 * version.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * this program; if not, write to the Free Software Foundation, Inc.,
 * 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 * 
 * ============================================================================== 
 */
 
#define DIVISIONSX 10
#define DIVISIONSY 8
#define SPECTDIVY   5
#define SPECTPHDIVY 4

#define MODE_STOP 1
#define MODE_RUN 2
#define MODE_HOLD 4
#define MODE_XY 8
#define MODE_FREQMAGLOG 16
#define MODE_CHAENABLED 32
#define MODE_CHBENABLED 64

#define RECONST_TRIANGLE 0
#define RECONST_SINC 1
#define RECONST_SQUARE 2
#define RECONST_POINT 3

#define SCOPE_SCREEN 0
#define SCOPE_FREQMAG 1
#define SCOPE_FREQPHASE 2

#define CM_SETSCREENTYPE    9001
#define CM_GETSCREENTYPE    9002

BOOL CALLBACK oscDispProc (HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam);

/* Gets the display configuration
 * windowMode:  three character array representing the window modes
 *     (SCOPE_SCREEN, SCOPE_FREQMAG, SCOPE_FREQPHASE)
 * returns: 1 */
int oscDispGetConfig(char windowMode[]);

/* Sets the display configuration
 * windowMode:  three character array representing the window modes
 *     (SCOPE_SCREEN, SCOPE_FREQMAG, SCOPE_FREQPHASE)
 * returns: 1 */
int oscDispSetConfig(char windowMode[]);

/* Clears and redraws all the scope windows 
 * returns: 0 */
int refreshScopeWindows();

/* Sets the channel to enabled or disabled 
 * ch: 0 is channel A, 1 is channel B
 * en: 1 is enabled, 0 is disabled
 * returns: 0 */
int setChannelEnabled(int ch, int en);

/* Gets the enabled status of the channel 
 * ch: 0 is channel A, 1 is channel B
 * returns: 1 is enabled, 0 is disabled */
int getChannelEnabled(int ch);

/* Returns the time per division */
double getTimePerDivision();

/* Gets the weight for drawing the channels
 * returns: weight in pixels */
int getPenWeight();

/* Sets the weight for drawing the channels
 * w: weight to use in pixels
 * returns: 0  */
int setPenWeight(int w);

