// #define NOHARDWARE
// #define DEBUGON
#define VERSIONTEXT      "Version 2.131 build 2/1/2011"
#define WINDOWTEXT       "PPMScope v.2.131"
