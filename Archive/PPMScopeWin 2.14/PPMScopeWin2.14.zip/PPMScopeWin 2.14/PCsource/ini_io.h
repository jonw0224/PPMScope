
#define RECCNT      50
#define COLCNT      2
#define RECLENGTH   100

int readConfigFile(char* fileName);

char* getConfigPar(char* parName);

int enumeratePrint();

int clearConfig();

int setConfigPar(char* parName, char* parValue);


    
