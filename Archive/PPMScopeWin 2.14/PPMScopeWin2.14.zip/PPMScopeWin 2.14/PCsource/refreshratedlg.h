/* ==============================================================================
 * Author:  Jonathan Weaver, jonw0224@netscape.net
 * E-mail Contact: jonw0224@netscape.net
 * Description:  Refresh Rate Dialog Box.
 * Version: 2.14
 * Date: 3/21/2011
 * Filename:  refreshratedlg.c, refreshratedlg.h
 *
 * Versions History:  
 *      2.14 - 3/21/2011 - Added refresh rate dialog
 *
 * Copyright (C) 2011 Jonathan Weaver
 * 
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU General Public License as published by the Free Software
 * Foundation; either version 2 of the License, or (at your option) any later
 * version.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * this program; if not, write to the Free Software Foundation, Inc.,
 * 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 * 
 * ============================================================================== 
 */

#define REFRESHRATEDLG            4200
#define REFRESHRATEDLG_ENTRY      4201
#define REFRESHRATEDLG_OK         4202
#define REFRESHRATEDLG_CANCEL     4203

/* Processes messages for the Hardware dialog box */
BOOL CALLBACK RefreshRateDlgProc (HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam);

