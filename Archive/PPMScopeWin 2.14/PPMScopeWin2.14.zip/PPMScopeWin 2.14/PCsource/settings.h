//#define NOHARDWARE
//#define DEBUGON

#define VERSIONTEXT      "Version 2.14 build 12/12/2011"
#define WINDOWTEXT       "PPMScope v.2.14"
#define COPYRIGHTTEXT    "(C) Copyright 2006-2011, Jonathan Weaver"
